#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
测试引用不存在包的脚本
"""

# 引用一个可能不存在的包
import nonexistent_package

print("如果你看到这条消息，说明你选择了继续执行代码")
print("但请注意，由于缺少依赖，代码可能无法正常工作") 